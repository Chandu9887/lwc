import { LightningElement } from 'lwc';
export default class SharpCorporation extends LightningElement {

}